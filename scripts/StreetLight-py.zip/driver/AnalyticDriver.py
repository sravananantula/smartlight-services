
def driver(*args,**kwargs):   
    from analytic import StreetLight
    da = StreetLight()
    return da.RelayCircuitCalculation(kwargs['Lumendata'])
