import psycopg2

class StreetLight:    

    def __init__(self):
        print "Street Light Analytic Started"

    ## Main Processing for Light to be ON/OFF
    ## Fetching Lumen value for each zone
    ## Processing the swtich toggling    
    def RelayCircuitCalculation(self,Lumendata):
        try:
            conn = psycopg2.connect("dbname='dfb5b711c51864ce583c73b18d3582dc0' user='u31bf106d0bae4f9ebc1bbd6b0f82591e' host='10.72.6.143' password='6e3686e1874a48ed89ea04132c32bd2f'")
            cur = conn.cursor()
            print "Database connected"
            cur.execute("Select ZoneID,LumenValue from tblZoneLumen")
            rows = cur.fetchall()
            sl=StreetLight()
            print "Toggling swtich processing"
            for row in rows:
                print row[0]
                print row[1]
                sl.ToggleSwitch(row[0],row[1])
            conn.commit()    
            conn.close()
            x="connected"
        except Exception as e:
            x=e
        return x

     ##Toggling the Switch based on below factors
     ##Between 7PM and 6AM ON
     ##After 1 AM Alternative Lights ON
     ##Rest of the time OFF AND
     ##If Lumen Value> 300 OFF
     ##If Lumen Value>200 AND <300 Alternative ON else All ON
     ##AND Health Should be Good   
    def ToggleSwitch(Self,ZoneID,LumenValue):
        try:           
            conn1 = psycopg2.connect("dbname='dfb5b711c51864ce583c73b18d3582dc0' user='u31bf106d0bae4f9ebc1bbd6b0f82591e' host='10.72.6.143' password='6e3686e1874a48ed89ea04132c32bd2f'")
            cur1 = conn1.cursor()
            print "DB2 Connected"
            if(LumenValue < 200):
                SQLQuery = "Update tblPoles Set Switch=1 Where healthstatus<>2 and ZoneID=" + str(ZoneID)
                print SQLQuery
                cur1.execute(SQLQuery)
                print "Update1"
            elif(LumenValue >= 200 and LumenValue < 300):
                SQLQuery = "Update tblPoles Set Switch=1 Where healthstatus<>2 and PoleId%2==0 ZoneID=" + str(ZoneID)
                print SQLQuery
                cur1.execute(SQLQuery)
                print "Update2"
            else:
                SQLQuery = "Update tblPoles Set Switch=0 Where ZoneID=" + str(ZoneID)
                print SQLQuery
                cur1.execute(SQLQuery)
                print "Update3"
            print "Update completed"
            conn1.commit()    
            conn1.close()            
        except Exception as e:            
            print e
    
                
