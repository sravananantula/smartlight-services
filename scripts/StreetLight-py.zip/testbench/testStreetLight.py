
from analytic import StreetLight

def main():
    with open('RotorLCF_InputData.json') as _fp:        
    result = rotorLCF(**Lumendata)
    print result
    
if __name__ == "__main__":    
    main()
